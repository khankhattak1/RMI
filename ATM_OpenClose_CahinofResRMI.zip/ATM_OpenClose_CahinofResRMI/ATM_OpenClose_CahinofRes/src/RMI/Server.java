/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package RMI;

/**
 *
 * @author lenevo
 */
import Controller.ControllerATM;
import java.rmi.*;

public class Server {
    public static void main(String args[]){
        try{
            IWithdraw stub = new Withdraw();
            Naming.rebind("rmi://localhost:5000/ARemote", stub);
        }
        catch(Exception e){
            System.out.println(e);
        }
    }
}
