/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package RMI;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

/**
 *
 * @author lenevo
 */
public class Withdraw extends UnicastRemoteObject implements IWithdraw {

    @Override
    public void demo1() throws RemoteException {
      
    }
    
   
    }


