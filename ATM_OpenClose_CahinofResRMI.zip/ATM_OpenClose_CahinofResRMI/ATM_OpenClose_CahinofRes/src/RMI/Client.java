/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package RMI;

/**
 *
 * @author lenevo
 */
import Controller.ControllerATM;
import View.GUIATM;
import java.rmi.*;

public class Client {
    
    public static void main(String args[]) throws Exception{
        try{
            IWithdraw stub =(IWithdraw)Naming.lookup("rmi://localhost:3306/ARemote");
            stub.demo1();
        }
        catch(Exception e){
            System.out.println(e);
        }
        finally{
            
        }
    }
}
